#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <string.h>
#include <math.h>
#include <iostream>
#include "hpdf.h"

void createPDF(double centerX, double centerY);
void writeChar(char text, float x, float y, float rad1, float rad2, float angle);
void savePDF();
